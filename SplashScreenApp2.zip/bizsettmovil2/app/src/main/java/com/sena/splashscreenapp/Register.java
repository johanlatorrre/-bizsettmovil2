package com.sena.splashscreenapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;

import android.os.Bundle;
import android.view.View;

public class Register extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

//        dash=findViewById(R.id.dash);
//        dash.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                Intent dash = new Intent(MainActivity.this, Dashboard.class);
//                startActivity(dash);
//            }
//        });

    }

    public void registrar(View view) {
        Intent login = new Intent(this, login.class);
        startActivity(login);

    }


    public void dash(View view) {
        Intent dash = new Intent(this, Dashboard.class);
        startActivity(dash);

    }

}

